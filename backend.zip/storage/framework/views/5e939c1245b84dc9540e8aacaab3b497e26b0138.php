<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="/css/index.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="detail-tamarind">
        <div class="column-top">
            <div class="text-top">
                <h1><?php echo e($main_content->title); ?></h1>
                <h2><?php echo e($main_content->description); ?></h2>
            </div>
            <div class="text-center">
                <?php echo $main_content->content; ?>

            </div>
            <div class="col-btn">
                <button onclick="location.href='menu'"><?php echo e($lang_config?$lang_config['FZUCKk7nZNrvIUF'] : ""); ?></button>
                <button onclick="location.href='delivery'"><?php echo e($lang_config?$lang_config['JgK5O34aOtM2JUW'] : ""); ?></button>
            </div>
        </div>
        <div class="column-contact">
            <div class="column-text">
                <div class="column-top">
                    <img src="<?php echo e($web_info->location->address->link); ?>" alt="address">
                    <h2><?php echo e($web_info->location->address->attribute); ?></h2>
                </div>
                <p style="text-align: left">
                    <?php echo e($web_info->location->address->value); ?><br>
                    <?php echo e($web_info->location->district->value); ?><br>
                    <?php echo e($web_info->location->province->value); ?>

                </p>
            </div>
            <div class="column-text">
                <div class="column-top">
                    <img src="<?php echo e($web_info->location->working_hours->link); ?>" alt="working">
                    <h2><?php echo e($web_info->location->working_hours->attribute); ?></h2>
                </div>
                
                <p><?php echo e($web_info->location->working_hours1->description); ?></p>: <span> <?php echo $web_info->location->working_hours1->value; ?></span>
            </div>
            <div class="column-text">
                <div class="column-top">
                    <img src="<?php echo e($web_info->contact->phone->link); ?>" alt="phone">
                    <h2><?php echo e($web_info->contact->phone->attribute); ?></h2>
                </div>
                <p><?php echo e($web_info->contact->phone->value); ?></p>
            </div>
        </div>
    </div>
    <div class="our-story" style="--our_image: url('/<?php echo e($page_story[0]->thumbnail_link); ?>')">
        <div class="column-story">
            <h2><?php echo e($page_story[0]->title); ?></h2>
            <div class="col-text">
                <div class="column-left" style="width: 50%;">
                    <?php echo $page_story[0]->content; ?>

                </div>
                <div class="column-right" style="width: 50%;">
                    <?php echo $page_story[1]->content; ?>

                    <button class="btn-bottom" onclick="location.href='gallery'"><?php echo e($lang_config?$lang_config['SjRAn7iEtdLlE1Z']:""); ?></button>
                </div>
            </div>
        </div>
    </div>
    <div class="column-img-menu">
        <?php if($page_content): ?>
            <?php $__currentLoopData = $page_content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($key !== 1): ?>
                    <div class="item">
                        <img src="/<?php echo e($content->image_link); ?>" alt="<?php echo e($content->alt); ?>">
                        <h2 class="middle"><?php echo e($content->title); ?></h2>
                    </div>
                <?php else: ?>
                    <div class=" item1">
                        <img class="col1" src="/<?php echo e($content->image_link); ?>" alt="<?php echo e($content->alt); ?>">
                        <div class="column-text">
                            <h2><?php echo e($content->title); ?></h2>
                            <button onclick="location.href='menu'"><?php echo e($content->alt); ?></button>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="/js/index.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.layout-main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\itservice\Desktop\Projects\Cha-Um\backend\resources\views/frontend/pages/index.blade.php ENDPATH**/ ?>